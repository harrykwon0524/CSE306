1. I had to seperate the patch file for part1 and part2,
but made a mistake and combined them. The patch file for both
parts may look the same
2. git diff for some reason did not include the kernel file that I made, so I amputting the file(encrypt.c) in the part2 folder for referenc
