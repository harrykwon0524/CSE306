#include <unistd.h>
#include <stdio.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <stdio.h>
#include <linux/userfaultfd.h>
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <signal.h>
#include <poll.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <sys/ioctl.h>
#include <poll.h>
#include <pthread.h>

#define BUFF 4096

static int pgsize;

int main(int argc, char *argv[]) {
    char buffer[BUFF] = {0};
    struct sockaddr_in localaddr, remoteaddr;
    int addrlen = sizeof(localaddr);
    int remotesocket, newsocket, localfd;
    int connectionfailed = 0, opt = 1;
    char *addr;
    unsigned long numpages,localport, remoteport  = 0, len = 0;

    if (argc != 3) {
        fprintf(stderr, "Enter two arguments");
        exit(EXIT_FAILURE);
    }
    else{
     localport = strtoul(argv[1], NULL, 0);
    remoteport = strtoul(argv[2], NULL, 0);
    printf("Local Port : %lu \n", localport);
    printf("Remote Port  : %lu \n", remoteport);

    }
   
    if ((localfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("Local Socket failed \n"); 
        exit(EXIT_FAILURE);
    }

    if ((remotesocket = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("Remote socket failed \n"); 
        exit(EXIT_FAILURE); 
    }

    if (setsockopt(localfd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt))) {
        perror("Socket opt failed \n"); 
        exit(EXIT_FAILURE); 
    }

    localaddr.sin_family = AF_INET;
    localaddr.sin_addr.s_addr = INADDR_ANY;
    localaddr.sin_port = htons(localport);

   
    memset(&remoteaddr, '0', sizeof(remoteaddr));
     remoteaddr.sin_family = AF_INET;
    remoteaddr.sin_port = htons(remoteport);

    if (bind(localfd, (struct sockaddr *) &localaddr, sizeof(localaddr)) < 0) {
        perror("Bind failed"); 
        exit(EXIT_FAILURE); 
    }

    if (inet_pton(AF_INET, "127.0.0.1", &remoteaddr.sin_addr) <= 0) {
        printf("Address not supported/Invalid address \n");
        return -1;
    }

    if (listen(localfd, 3) < 0) {
        perror("Listen Failed \n"); 
        exit(EXIT_FAILURE); 
    }
    
    printf("Listening on port %lu .. \n", localport);

    if (!connectionfailed) {
    if (connect(remotesocket, (struct sockaddr *) &remoteaddr, sizeof(remoteaddr)) < 0) {
        printf("Fist Connection Failed \n");
        connectionfailed++;
        } else {
            printf("First Connection Success \n");
        }

        }
    printf("Waiting from remote \n");

    if ((newsocket = accept(localfd, (struct sockaddr *) &localaddr,(socklen_t *) &addrlen)) < 0) {
        perror("Accept failed\n"); 
        exit(EXIT_FAILURE); 
    }
        printf("Connection accepted from Remote \n");
    
    

    if (connectionfailed) {
        if (connect(remotesocket, (struct sockaddr *) &remoteaddr, sizeof(remoteaddr)) < 0) {
            printf("Subsequent Connection Fail \n");
        } else {
            printf("Subsequent Connection Success \n");
        }
    }
    pgsize = sysconf(_SC_PAGE_SIZE);

    if (connectionfailed) {
        printf("How many pages would you like to allocate? \n");
        if (scanf("%lu", &numpages) == EOF) { 
        perror("EOF on input"); 
        }
        len = numpages * pgsize;
        addr = mmap(NULL, len, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if (addr == MAP_FAILED) {
            perror("Error in allocation ");
            exit(EXIT_FAILURE);
        }
        printf("The mmapped memory : %lu\n", len);
        printf("Mapping address at : %p\n", addr);
        snprintf(buffer, BUFF, "%lu-%p", len, addr);
        send(remotesocket, buffer, strlen(buffer), 0);

    } else {
        if (read(newsocket, buffer, 1024) < 0) {
            perror("Read failed \n");
            exit(EXIT_FAILURE);
        }
        char *token;
        token = strtok(buffer, "-");
        len = strtoul(token, NULL, 0);
        printf("Memory length from peer %lu\n", len);
        numpages = len / pgsize;
        token = strtok(NULL, "-");
        addr = token;
        printf("Address from peer: %s \n", token);
        sscanf(token, "%p", &addr);
        addr = mmap(addr, len, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        printf("Address by mmap: %p \n\n", addr);

        if (addr == MAP_FAILED) {
        perror("error in mmap "); 
        exit(EXIT_FAILURE); 
        }

    }

 }