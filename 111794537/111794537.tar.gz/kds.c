#include <linux/module.h>   
#include <linux/kernel.h>   
#include <linux/init.h>
#include <linux/slab.h>
#include <linux/string.h>   
#include <linux/rbtree.h>
#include <linux/bitmap.h>
#include <linux/bitops.h>
#include <linux/list.h>
#include <linux/hashtable.h>
#include <linux/types.h>
#include <linux/radix-tree.h>
#include <linux/xarray.h>

static char *int_str = "11 44 22 33 5";
module_param(int_str, charp, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
MODULE_PARM_DESC(int_str, "Input string");


struct rbtree {
    struct rb_node node;
    int val;
};

struct linkedlist {
    struct list_head node;
    int val;
};

struct datanode {
    int val;
};

struct myhashnode {
    struct hlist_node hash;
    int val;
};

DEFINE_HASHTABLE(myhashtable, 14);


void linked_print(struct list_head *head) {
    struct linkedlist *cur;
    list_for_each_entry(cur, head, node) {
       printk(KERN_INFO "Value: %d\n", cur->val);
    }
}

void linked_run(int * array, int cnt) {
    struct linkedlist *node, *cur, *next;
    int idx = 0;
   LIST_HEAD(listhead);

    while(idx < cnt) {
        node = (struct linkedlist *)kmalloc(sizeof(struct linkedlist), GFP_KERNEL);
        node->val = array[idx];
        idx++;
        list_add(&node->node, &listhead);
        printk(KERN_INFO "Element added : %d \n", node->val);
    }

    linked_print(&listhead);

    printk(KERN_INFO "Remove elements");
    list_for_each_entry_safe(cur, next, &listhead, node){
        list_del(&cur->node);
        kfree(cur);
    }

    linked_print(&listhead);
}

void rb_print(struct rb_root * root) {
    struct rb_node *node;
    if(rb_first(root)) {
    for (node = rb_first(root); node; node = rb_next(node)) {
        printk(KERN_INFO "Value = %d\n", rb_entry(node, struct rbtree, node)->val);
    }
    }
    else{
    printk(KERN_INFO "Root null");
    }
}

int rb_insert(struct rbtree *mynode, struct rb_root *root) {
    struct rb_node *parent = NULL, **new = &(root->rb_node);
    while (*new) {
        
        struct rbtree *temp = container_of(*new, struct rbtree, node);
        parent = *new;
        if (mynode->val > temp->val)
            new = &((*new)->rb_right);
        else if (mynode->val < temp->val)
            new = &((*new)->rb_left);
        else
            return 0;
            }
    rb_link_node(&mynode->node, parent, new);
    rb_insert_color(&mynode->node, root);
    printk(KERN_INFO "Integer Inserted: %d ", mynode-> val);
    return 1;
    }
   

int rb_lookup(struct rb_root *root, int number) {
    struct rb_node *parent = NULL, **new = &(root->rb_node);
    while (*new) {
        
        struct rbtree *temp = container_of(*new, struct rbtree, node);
        parent = *new;
        if (number > temp->val)
            new = &((*new)->rb_right);
        else if (number < temp->val)
            new = &((*new)->rb_left);
        else {
        printk(KERN_INFO "Lookup found element : %d \n", number);
            return number;
        }
    }
    return -1;
}

void rb_remove(struct rb_root * root) {
    struct rb_node *node;
    for (node = rb_first(root); node; node = rb_next(node))
    {
      struct rbtree *temp = rb_entry(node, struct rbtree, node); 
      rb_erase(&(temp->node), root);
      kfree(temp);
  }
  printk(KERN_INFO "RB Tree Erased");

}

void rb_run(int * array, int cnt) {
    int look = 0, idx = 0, number;
    struct rb_root root = RB_ROOT;
    struct rbtree * newnode;
    rb_print(&root);

    while(idx< cnt) {
        newnode = (struct rbtree *)kmalloc(sizeof(struct rbtree), GFP_KERNEL);
        newnode->val = array[idx];
        rb_insert(newnode, &root);
        rb_print(&root);
        idx++;
    }
    idx=0;
    while(idx< cnt) {
        number = array[idx];
        look = rb_lookup(&root, number);
        if(look < 0 ){
        printk(KERN_INFO "Element not found : %d \n", number);
        }
        else{
        printk(KERN_INFO "Lookup found element : %d \n", number);
        }
            
        idx++;
    }

    rb_remove(&root);
    rb_print(&root);
}



void lookup_radix_tree(struct radix_tree_root * my_radix, int * int_array, int count) {
    int i=0;
    unsigned long number;
    struct datanode * radix_node;
    while(i<count) {
        number = int_array[i++];
        radix_node = radix_tree_lookup(my_radix, number);
        if (radix_node == NULL)
        {
            printk(KERN_INFO "Element not found: %lu \n", number);
        } else {
            printk(KERN_INFO "Element found: %d \n", radix_node->val);
        }
    }
}

void radix_lookup(struct radix_tree_root * radix, int * array, int cnt) {
struct datanode * radixnode;    
int idx=0;
    unsigned long number;
    while(idx<cnt) {
        number = array[idx];
        radixnode = radix_tree_lookup(radix, number);
        if (radixnode != NULL)
        {
        printk(KERN_INFO "Integer : %d \n", radixnode->val);
        } else {
             printk(KERN_INFO "Integer not found: %lu \n", number);
        }
        idx++;
    }
}

void radix_tag(struct radix_tree_root * radix, int * array, int cnt) {
    
    unsigned long number;
    int idx=0;
    int tag = 1;
    while(idx<cnt) {
        number = array[idx];
        if (number % 2 == 1)
        {
        printk(KERN_INFO "Tagging: %lu \n", number);
            radix_tree_tag_set(radix, number, tag);
            
        }
        idx++;
    }
}

void tagged_lookup(struct radix_tree_root * radix) {
    struct datanode * res[10];
    int idx = 0;
    unsigned int cnt;

    cnt = radix_tree_gang_lookup_tag(radix, (void *)res, 0, 100, 1);
    printk(KERN_INFO "Count of tagged: %d ", cnt);
    
    for (idx = 0; idx< cnt; idx++) {
        printk(KERN_INFO "Tagged gang looked up: %d ", res[idx]->val);
    }
}

void radix_remove(struct radix_tree_root * radix, int * array, int cnt) {
   
    unsigned long number;
    struct datanode * radixnode;
     int idx=0;

    while(idx<cnt) {
        number = array[idx];
        radixnode = radix_tree_delete(radix, number);
        if (radixnode != NULL)
        {
        printk(KERN_INFO "deleted: %d \n", radixnode -> val);
            kfree(radixnode);
            
        } else {
            printk(KERN_INFO "Integer to delete not found: %lu \n", number);
        }
        idx++;
    }
}


void radix_run(int * array, int cnt) {
    
    struct datanode * radixnode;

    int idx = 0;
    RADIX_TREE(radix, GFP_KERNEL);

    while(idx<cnt) {
        radixnode = (struct datanode *)kmalloc(sizeof(struct datanode), GFP_KERNEL);
        radixnode->val = array[idx];
        
        radix_tree_insert(&radix, radixnode->val, radixnode); 
        printk(KERN_INFO "inserted: %d \n", radixnode-> val);
        idx++;
        }

    radix_lookup(&radix, array, cnt);
    radix_tag(&radix, array, cnt);
    tagged_lookup(&radix);    
    radix_remove(&radix, array, cnt);

}

void bitmap_run(int * array, int cnt) {
        unsigned long bit;
        int num;
        unsigned long idx = 0;
        DECLARE_BITMAP(bitmap, 10);
        bitmap_zero(bitmap, 10);

        while (idx < cnt) {
            bit = 0;
            num = array[idx];
            while(num > 0) {
                if (num % 2 == 1) {   
                    printk(KERN_INFO "Bit %lu", bit);
                    set_bit(bit, bitmap);
                }
                bit++; 
                num = num/2;
            }
            idx++;
        }
        printk(KERN_INFO "Print set bits\n");
        for_each_set_bit(bit, bitmap, 10){
            printk(KERN_INFO "%lu \n", bit);
        }
        bitmap_zero(bitmap, 10);
        printk(KERN_INFO "Cleared all the bits \n");
}

static int __init lkp_init(void)
{
int * array;
    int idx = 0, cnt  = 0;
    int i = 0, j = 0, value = 0;
    
    printk(KERN_INFO "Module loaded ...\n");

    /* Counting the number of integers */
    while(int_str[idx]!= '\0') {
      if (int_str[idx] != ' ') {          
          
      }
      else{
            cnt++;
      }
      idx++;
  }
  cnt++;

  array = kmalloc(cnt * sizeof(int), GFP_KERNEL);


    while (int_str[i] != '\0' && j<cnt) {
        if (int_str[i] != ' '){
        value = value * 10 + (int_str[i] - '0');
        } else {
            array[j++] = value; 
            value = 0; 
        } 
        i++;
    }
    array[j] = value;

    /* Print integers */


   printk(KERN_INFO "Linked List\n");
    linked_run(array, cnt);

    printk(KERN_INFO "Red Black Trees\n");
    rb_run(array, cnt);

    printk(KERN_INFO "Radix Tree\n");
    radix_run(array, cnt);

    printk(KERN_INFO "Bitmap\n");
    bitmap_run(array, cnt);

    kfree(array);
    return 0; 
}

static void __exit lkp_exit(void)
{
    printk(KERN_INFO "Module exit ...\n");
}
module_init(lkp_init); /* lkp_init() will be called at loading the module */
module_exit(lkp_exit); /* lkp_exit() will be called at unloading the module */

MODULE_LICENSE("GPL");
