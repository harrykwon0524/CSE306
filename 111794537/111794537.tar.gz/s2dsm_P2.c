#include <unistd.h>
#include <stdio.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <stdio.h>
#include <linux/userfaultfd.h>
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <signal.h>
#include <poll.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <sys/ioctl.h>
#include <poll.h>
#include <pthread.h>
#include <stdbool.h>

#define BUFF 4096

static char *baseaddress;

static int pgsize, remotesocket, newsocket;

enum msi {m, s, i};

static enum msi msiarray[100];

static unsigned long numpages;

char msitype(enum msi val) {
    switch (val) {
        case m: return 'M';
        case s: return 'S';
        case i: return 'I';
        default : return '\0';
    }
}

    void errmsg(char *msg){
do {
perror(msg); 
exit(EXIT_FAILURE);    
    } while (0);
    }

    static char *response(int pg) {
    enum msi status = msiarray[pg];
    switch (status) {
        case m:
            msiarray[pg] = s;
        case s:
            return (baseaddress + (pg * pgsize));
        case i:
            return "nothing";
    }
    return '\0';
}


    static void *responding(void *arg) {
    char buffer[pgsize];
            int byteread = 0;
    for (;;) {

        memset(buffer, '\0', pgsize);
        byteread = read(newsocket, buffer, pgsize);
        if (byteread > 0) {
            char msg[pgsize];
            char *newbuffer;
            newbuffer = strtok(buffer, "-");
            int requestpg = atoi(newbuffer);
            enum msi initial = msiarray[requestpg];
            newbuffer = strtok(NULL, "-");
            int op = atoi(newbuffer);
            printf("\nRequest for : %d , 1 for reading and 2 for invalidating: %d \n", requestpg, op);
            if (op == 2) {
                char * page_addr = baseaddress + (requestpg * pgsize);
                msiarray[requestpg] = i;
                if (madvise(page_addr, pgsize, MADV_DONTNEED)) {
                    errmsg("Fail to madvise");
                }
                snprintf(msg, pgsize, "Success");
            } else if (op == 1) {
                char * receivedmsg;
                receivedmsg = response(requestpg);
                enum msi status = msiarray[requestpg];
                    switch (status) {
                        case m:
                            msiarray[requestpg] = s;
                            break;
                        case s:
                        case i:
                            break;
    }
                snprintf(msg, pgsize, "%s", receivedmsg);

            }
            printf("Page State was: %c . Now : %s\n", msitype(initial) ,msg);
            send(newsocket, msg, strlen(msg), 0);
        }
         else if (byteread < 0) {
            perror("Reading error");
            exit(EXIT_FAILURE);
        } 
    }
}
        

    static void *faulthandler(void *arg) {

    static struct uffd_msg msg;
    struct uffdio_copy uffdiocopy;
    long uffd;
    static char *pg = NULL;
    ssize_t readnum;

            struct pollfd pollfd;
        int polls;

    uffd = (long) arg;
    if (pg == NULL) {
        pg = mmap(NULL, pgsize, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if (pg == MAP_FAILED)
         errmsg("Mmap error");
    }

    for(;;){
        pollfd.fd = uffd;
        pollfd.events = POLLIN;
        polls = poll(&pollfd, 1, -1);
        if (polls == -1)
            errmsg("Poll error");

        printf(" [x] PAGEFAULT\n");

        readnum = read(uffd, &msg, sizeof(msg));

        if (msg.event != UFFD_EVENT_PAGEFAULT) {
            fprintf(stderr, "Unexpected userfaultfd\n");
            exit(EXIT_FAILURE);
        }

                if (readnum == 0) {
            printf("EOF!\n");
            exit(EXIT_FAILURE);
        }

        if (readnum == -1){
            errmsg("Read error");

            }

        memset(pg, '\0', pgsize);
        uffdiocopy.len = pgsize;
        uffdiocopy.src = (unsigned long) pg;
        uffdiocopy.dst = (unsigned long) msg.arg.pagefault.address & ~(pgsize - 1);
        uffdiocopy.mode = 0;
        uffdiocopy.copy = 0;

        if (ioctl(uffd, UFFDIO_COPY, &uffdiocopy) == -1)
            errmsg("ioctl-UFFDIO_COPY error");
    }
}

char * communicatepeer(int requestpg, int op) {
    char * result;
    char msg[pgsize];
    //ret ����
    sprintf(msg, "%d-%d", requestpg , op);
    send(remotesocket, msg, strlen(msg), 0);
    memset(msg, '\0', pgsize); 
    int byteread = 0;
    byteread = read(remotesocket, msg, pgsize);
    if (byteread == 0) {
        printf("0 bytes \n");
        msg[0] = '\0';
    } else if (byteread < 0) {
        perror("read error");
        exit(EXIT_FAILURE);
    } 
    result = msg;
    return result;
}

void updatepg(char * addr, int requestpg, unsigned long numpages, const char *msg, bool change) {
    int posi;
    int idx = requestpg;
    int dest = requestpg;
    if(requestpg == -1){
        idx = 0;
        dest = numpages - 1;
    }
    for (; idx <= dest; ++idx) {
        posi = 0x0 + (idx * pgsize);
        for (int j = 0; msg[j] != '\0'; ++j) {
            addr[posi++] = msg[j];
        }
        addr[posi] = '\0';
        if(change == true){
            enum msi status = msiarray[idx];
            switch (status){
                case m:
                case s:
                case i:
                    msiarray[idx] = m;
                    printf("Writing Page %d, Status changed to M, Invalidated \n", idx);
                    communicatepeer(idx, 2);
                    break;
                       }
        }
    }
}

    void printpg(char * addr, unsigned long numpages, int requestpg, bool status) {
    char output[pgsize + 1];
    int idx = requestpg;
    int dest = requestpg;
    char * msg;
    if(requestpg == -1){
        idx = 0;
        dest = numpages - 1;
    }
    for (; idx <= dest; ++idx) {
        sprintf(output, "%s", addr + (idx * pgsize));
        enum msi stage = msiarray[idx];
        switch (stage) {
            case m:
            case s:
                break;
            case i:
                printf("State of page I. Received remotely \n");
                char result[] = "";
                if(status == true) {
                    msg = communicatepeer(idx, 1);
                    if(strcmp("nothing", msg)==0) {
                    char * pgaddr = baseaddress + (idx * pgsize);
                        if (madvise(pgaddr, pgsize, MADV_DONTNEED)) {
                            errmsg("Fail to madvise");
                        }
                        /*msg = result;�ѹ� �ؿ� �ֺ�*/ 
                    } else {
                        updatepg(addr, idx, numpages, msg, false);
                        msiarray[idx] = s;
                    }
                } /*else {
                msg = result;
                }*/
                msg = result;
                sprintf(output, "%s", msg);
                break;
        }
        printf("Page %d contains \n%s\n", idx, output);
    }
}

int main(int argc, char *argv[]) {
    char buffer[BUFF] = {0};
    struct sockaddr_in localaddr, remoteaddr;
    int addrlen = sizeof(localaddr);
    int localfd;
    int connectionfailed = 0, opt = 1;
    char *addr;
    unsigned long localport, remoteport  = 0, len = 0;

    if (argc != 3) {
        fprintf(stderr, "Enter two arguments");
        exit(EXIT_FAILURE);
    }
    else{
     localport = strtoul(argv[1], NULL, 0);
    remoteport = strtoul(argv[2], NULL, 0);
    printf("Local Port : %lu \n", localport);
    printf("Remote Port  : %lu \n", remoteport);

    }
   
    if ((localfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
    errmsg("Local Socket failed \n");
    }

    if ((remotesocket = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
    errmsg("Remote socket failed \n");
    }

    if (setsockopt(localfd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt))) {
    errmsg("Socket opt failed \n");
    }

    localaddr.sin_family = AF_INET;
    localaddr.sin_addr.s_addr = INADDR_ANY;
    localaddr.sin_port = htons(localport);

   
    memset(&remoteaddr, '0', sizeof(remoteaddr));
     remoteaddr.sin_family = AF_INET;
    remoteaddr.sin_port = htons(remoteport);

    if (bind(localfd, (struct sockaddr *) &localaddr, sizeof(localaddr)) < 0) {
    errmsg("Bind failed");
    }

    if (inet_pton(AF_INET, "127.0.0.1", &remoteaddr.sin_addr) <= 0) {
        printf("Address not supported/Invalid address \n");
        return -1;
    }

    if (listen(localfd, 3) < 0) {
    errmsg("Listen Failed \n");

    }
    
    printf("Listening on port %lu .. \n", localport);

    if (!connectionfailed) {
    if (connect(remotesocket, (struct sockaddr *) &remoteaddr, sizeof(remoteaddr)) < 0) {
        printf("Fist Connection Failed \n");
        connectionfailed++;
        } else {
            printf("First Connection Success \n");
        }

        }
    printf("Waiting from remote \n");

    if ((newsocket = accept(localfd, (struct sockaddr *) &localaddr,(socklen_t *) &addrlen)) < 0) {
    errmsg("Accept Failed \n");
    }
        printf("Connection accepted from Remote \n");
    
    

    if (connectionfailed) {
        if (connect(remotesocket, (struct sockaddr *) &remoteaddr, sizeof(remoteaddr)) < 0) {
            printf("Subsequent Connection Fail \n");
        } else {
            printf("Subsequent Connection Success \n");
        }
    }
    pgsize = sysconf(_SC_PAGE_SIZE);

    if (connectionfailed) {
        printf("How many pages would you like to allocate? \n");
        if (scanf("%lu", &numpages) == EOF) { 
        errmsg("EOF on input");
        }
        len = numpages * pgsize;
        addr = mmap(NULL, len, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if (addr == MAP_FAILED) {
        errmsg("Error in allocation");
        }
        printf("The mmapped memory : %lu\n", len);
        printf("Mapping address at : %p\n", addr);
        snprintf(buffer, BUFF, "%lu-%p", len, addr);
        send(remotesocket, buffer, strlen(buffer), 0);

    } else {
        if (read(newsocket, buffer, 1024) < 0) {
             errmsg("Read failed \n");
        }
        char *token;
        token = strtok(buffer, "-");
        len = strtoul(token, NULL, 0);
        printf("Memory length from peer %lu\n", len);
        numpages = len / pgsize;
        token = strtok(NULL, "-");
        addr = token;
        printf("Address from peer: %s \n", token);
        sscanf(token, "%p", &addr);
        addr = mmap(addr, len, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        printf("Address by mmap: %p \n\n", addr);

        if (addr == MAP_FAILED) {
         errmsg("error in mmap\n");
        }

    }


    baseaddress = addr;

    char mode;
    char msg[pgsize];
    int requestpg, s;
    long uffd;
    struct uffdio_api uffdioapi;
    struct uffdio_register uffdioregister;
    pthread_t thr;
    
    /* Registering userfaultfd file descriptor */

    uffd = syscall(__NR_userfaultfd, O_CLOEXEC | O_NONBLOCK);
    if (uffd == -1) {
            errmsg("userfaultfd");
/* perror("userfaultfd\n"); 
        exit(EXIT_FAILURE); */
    }
    uffdioapi.api = UFFD_API;
    uffdioapi.features = 0;
    if (ioctl(uffd, UFFDIO_API, &uffdioapi) == -1) {
     errmsg("ioctl-UFFDIO_API");
/* perror("mmap\n"); 
        exit(EXIT_FAILURE); */
    }
    uffdioregister.range.start = (unsigned long) addr;
    uffdioregister.range.len = len;
    uffdioregister.mode = UFFDIO_REGISTER_MODE_MISSING;
    if (ioctl(uffd, UFFDIO_REGISTER, &uffdioregister) == -1)
     errmsg("ioctl-UFFDIO_REGISTER");
/* perror("mmap\n"); 
        exit(EXIT_FAILURE); */

    s = pthread_create(&thr, NULL, faulthandler, (void *) uffd);
    if (s != 0) {
        errno = s;
         errmsg("pthread_create");
    }

    pthread_t thread;
    for (int idx = 0; idx <= numpages; ++idx) {
        msiarray[idx] = i;
    }
    thread = pthread_create(&thread, NULL, responding, (void *) uffd);
    if(thread != 0){
        errno = thread;
        errmsg("pthread_create");
    }

    /* operations */
    do {
        
        printf("> Which command ? ");
        if(scanf(" %c", &mode) != '\0'){

        }
       
        
        if (mode == 'r') {
        printf("\n> Which page? (-1 for all): ");
        
        
         if(scanf(" %d", &requestpg) != '\0'){

         }
            printpg(addr, numpages, requestpg, true);
        } else if (mode == 'w') {
        printf("\n> Which page? (-1 for all): ");
        
        
         if(scanf(" %d", &requestpg) != '\0'){

         }
            printf("> Type your input: \n");
            if(scanf(" %[^\n]", msg) != '\0'){

            }
            if (strlen(msg) > pgsize) {
                printf("The length of message is too long. The message will be trimmed \n");
            }
            updatepg(addr, requestpg, numpages, msg, true);
            printpg(addr, numpages, requestpg, false);
            } 
            else if(mode == 'v'){
    for (int idx = 0; idx < numpages; ++idx) {
        printf("Page %d : %c \n", idx, msitype(msiarray[idx]));
            }
        } else {
            printf("Not a valid option : r or w");
        }
    } while (1);
    return 0;
}




