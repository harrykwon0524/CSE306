#include <unistd.h>
#include <stdio.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <stdio.h>
#include <linux/userfaultfd.h>
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <signal.h>
#include <poll.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <sys/ioctl.h>
#include <poll.h>
#include <pthread.h>

#define BUFF 4096

static int pgsize;

    void errmsg(char *msg){
do {
perror(msg); 
exit(EXIT_FAILURE);    
    } while (0);
    }

    static void *faulthandler(void *arg) {
    static struct uffd_msg msg;
    struct uffdio_copy uffdiocopy;
    long uffd;
    static char *pg = NULL;
    struct pollfd pollfd;
    int polls;
    ssize_t readnum;

    uffd = (long) arg;
    if (pg == NULL) {
        pg = mmap(NULL, pgsize, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if (pg == MAP_FAILED)
         errmsg("Mmap error");
        /* perror("mmap\n"); 
        exit(EXIT_FAILURE); */
    }

    for(;;){
        pollfd.fd = uffd;
        pollfd.events = POLLIN;
        polls = poll(&pollfd, 1, -1);
        if (polls == -1)
        errmsg("Poll error");
        /* perror("mmap\n"); 
        exit(EXIT_FAILURE); */

        printf(" [x] PAGEFAULT\n");

        readnum = read(uffd, &msg, sizeof(msg));
        if (readnum == 0) {
            errmsg("EOF");
        }

        else if (readnum == -1)
        errmsg("Read error");
        /* perror("mmap\n"); 
        exit(EXIT_FAILURE); */

        if (msg.event != UFFD_EVENT_PAGEFAULT) {
            fprintf(stderr, "Unexpected userfaultfd\n");
            exit(EXIT_FAILURE);
        }

        memset(pg, '\0', pgsize);
        uffdiocopy.len = pgsize;
        uffdiocopy.src = (unsigned long) pg;
        uffdiocopy.dst = (unsigned long) msg.arg.pagefault.address & ~(pgsize - 1);
        uffdiocopy.mode = 0;
        uffdiocopy.copy = 0;

        if (ioctl(uffd, UFFDIO_COPY, &uffdiocopy) == -1)
         errmsg("ioctl-UFFDIO_COPY error");
        /* perror("mmap\n"); 
        exit(EXIT_FAILURE); */
    }
}

    void printpg(const char *addr, unsigned long numpages, int requestpg) {
    char output[pgsize + 1];
    int idx = requestpg;
    int dest = requestpg;
    if(requestpg == -1){
        idx = 0;
        dest = numpages - 1;
    }
    for (; idx <= dest; ++idx) {
        sprintf(output, "%s", addr + (idx * pgsize));
        printf("Page %d contains \n%s\n", idx, output);
    }
}


void updatepg(char *addr, int requestpg, unsigned long numpages, const char *msg) {
    int posi;
    int idx = requestpg;
    int dest = requestpg;
    if(requestpg == -1){
        idx = 0;
        dest = numpages - 1;
    }
    for (; idx <= dest; ++idx) {
        posi = 0x0 + (idx * pgsize);
        for (int j = 0; msg[j] != '\0'; ++j) {
            addr[posi++] = msg[j];
        }
        addr[posi] = '\0';
    }
}

int main(int argc, char *argv[]) {
    char buffer[BUFF] = {0};
    struct sockaddr_in localaddr, remoteaddr;
    int addrlen = sizeof(localaddr);
    int remotesocket, newsocket, localfd;
    int connectionfailed = 0, opt = 1;
    char *addr;
    unsigned long numpages,localport, remoteport  = 0, len = 0;

    if (argc != 3) {
        fprintf(stderr, "Enter two arguments");
        exit(EXIT_FAILURE);
    }
    else{
     localport = strtoul(argv[1], NULL, 0);
    remoteport = strtoul(argv[2], NULL, 0);
    printf("Local Port : %lu \n", localport);
    printf("Remote Port  : %lu \n", remoteport);

    }
   
    if ((localfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
    errmsg("Local Socket failed \n");
    }

    if ((remotesocket = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
    errmsg("Remote socket failed \n");
    }

    if (setsockopt(localfd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt))) {
    errmsg("Socket opt failed \n");
    }

    localaddr.sin_family = AF_INET;
    localaddr.sin_addr.s_addr = INADDR_ANY;
    localaddr.sin_port = htons(localport);

   
    memset(&remoteaddr, '0', sizeof(remoteaddr));
     remoteaddr.sin_family = AF_INET;
    remoteaddr.sin_port = htons(remoteport);

    if (bind(localfd, (struct sockaddr *) &localaddr, sizeof(localaddr)) < 0) {
    errmsg("Bind failed");
    }

    if (inet_pton(AF_INET, "127.0.0.1", &remoteaddr.sin_addr) <= 0) {
        printf("Address not supported/Invalid address \n");
        return -1;
    }

    if (listen(localfd, 3) < 0) {
    errmsg("Listen Failed \n");

    }
    
    printf("Listening on port %lu .. \n", localport);

    if (!connectionfailed) {
    if (connect(remotesocket, (struct sockaddr *) &remoteaddr, sizeof(remoteaddr)) < 0) {
        printf("Fist Connection Failed \n");
        connectionfailed++;
        } else {
            printf("First Connection Success \n");
        }

        }
    printf("Waiting from remote \n");

    if ((newsocket = accept(localfd, (struct sockaddr *) &localaddr,(socklen_t *) &addrlen)) < 0) {
    errmsg("Accept Failed \n");
    }
        printf("Connection accepted from Remote \n");
    
    

    if (connectionfailed) {
        if (connect(remotesocket, (struct sockaddr *) &remoteaddr, sizeof(remoteaddr)) < 0) {
            printf("Subsequent Connection Fail \n");
        } else {
            printf("Subsequent Connection Success \n");
        }
    }
    pgsize = sysconf(_SC_PAGE_SIZE);

    if (connectionfailed) {
        printf("How many pages would you like to allocate? \n");
        if (scanf("%lu", &numpages) == EOF) { 
        errmsg("EOF on input");
        }
        len = numpages * pgsize;
        addr = mmap(NULL, len, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if (addr == MAP_FAILED) {
        errmsg("Error in allocation");
        }
        printf("The mmapped memory : %lu\n", len);
        printf("Mapping address at : %p\n", addr);
        snprintf(buffer, BUFF, "%lu-%p", len, addr);
        send(remotesocket, buffer, strlen(buffer), 0);

    } else {
        if (read(newsocket, buffer, 1024) < 0) {
             errmsg("Read failed \n");
        }
        char *token;
        token = strtok(buffer, "-");
        len = strtoul(token, NULL, 0);
        printf("Memory length from peer %lu\n", len);
        numpages = len / pgsize;
        token = strtok(NULL, "-");
        addr = token;
        printf("Address from peer: %s \n", token);
        sscanf(token, "%p", &addr);
        addr = mmap(addr, len, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        printf("Address by mmap: %p \n\n", addr);

        if (addr == MAP_FAILED) {
         errmsg("error in mmap\n");
        }

    }


    char mode;
    char msg[pgsize];
    int requestpg, s;
    long uffd;
    struct uffdio_api uffdioapi;
    struct uffdio_register uffdioregister;
    pthread_t thr;
    
    /* Registering userfaultfd file descriptor */

    uffd = syscall(__NR_userfaultfd, O_CLOEXEC | O_NONBLOCK);
    if (uffd == -1) {
            errmsg("userfaultfd");
/* perror("userfaultfd\n"); 
        exit(EXIT_FAILURE); */
    }
    uffdioapi.api = UFFD_API;
    uffdioapi.features = 0;
    if (ioctl(uffd, UFFDIO_API, &uffdioapi) == -1) {
     errmsg("ioctl-UFFDIO_API");
/* perror("mmap\n"); 
        exit(EXIT_FAILURE); */
    }
    uffdioregister.range.start = (unsigned long) addr;
    uffdioregister.range.len = len;
    uffdioregister.mode = UFFDIO_REGISTER_MODE_MISSING;
    if (ioctl(uffd, UFFDIO_REGISTER, &uffdioregister) == -1)
     errmsg("ioctl-UFFDIO_REGISTER");
/* perror("mmap\n"); 
        exit(EXIT_FAILURE); */

    s = pthread_create(&thr, NULL, faulthandler, (void *) uffd);
    if (s != 0) {
        errno = s;
         errmsg("pthread_create");
/* perror("mmap\n"); 
        exit(EXIT_FAILURE); */
    }

    /* Starting user for operations */
    do {
        
        printf("> Which command ? ");
        if(scanf(" %c", &mode) != '\0'){

        }
        printf("\n> Which page? (-1 for all): ");
         if(scanf(" %d", &requestpg) != '\0'){

         }
        if (mode == 'r') {
            printpg(addr, numpages, requestpg);
        } else if (mode == 'w') {
            printf("> Type your input: \n");
            if(scanf(" %[^\n]", msg) != '\0'){

            }
            if (strlen(msg) > pgsize) {
                printf("The length of message is too long. The message will be trimmed \n");
            }
            updatepg(addr, requestpg, numpages, msg);
            printpg(addr, numpages, requestpg);
            
        } else {
            printf("Not a valid option : r or w");
        }
    } while (1);

    return 0;
}




