when you perform cd mnt/foo, it causes permission denied error, so sudo su needs to be done first 
